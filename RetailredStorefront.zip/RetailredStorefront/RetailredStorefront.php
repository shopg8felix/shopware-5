<?php

namespace RetailredStorefront;

use Shopware\Components\Plugin;

class RetailredStorefront extends Plugin
{

}
